#!/bin/bash
# Claude Usage 메뉴바 설치 스크립트 — 사용법: bash install.sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
PLUGIN_DIR="$DIR/plugin"

if ! security find-generic-password -s "Claude Code-credentials" >/dev/null 2>&1; then
  echo "Claude Code 로그인 정보가 없습니다. 터미널에서 'claude' 실행 후 로그인하고 다시 실행하세요."; exit 1
fi

# brew가 PATH에 없어도 설치돼 있을 수 있음 (Apple Silicon / Intel 기본 경로)
if ! command -v brew >/dev/null; then
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do
    [ -x "$b" ] && eval "$("$b" shellenv)" && break
  done
fi

if ! command -v brew >/dev/null; then
  if ! id -Gn | tr ' ' '\n' | grep -qx admin; then
    echo "Homebrew 설치에는 관리자 권한이 필요합니다. IT 담당자에게 문의하세요."; exit 1
  fi
  echo "Homebrew를 설치합니다. Mac 로그인 비밀번호를 물어보면 입력하세요."
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do
    [ -x "$b" ] && eval "$("$b" shellenv)" && break
  done
  command -v brew >/dev/null || { echo "Homebrew 설치 실패. 위 오류 메시지를 확인하세요."; exit 1; }
  # 이후 터미널에서도 brew를 쓸 수 있도록 등록
  grep -q "brew shellenv" ~/.zprofile 2>/dev/null || echo "eval \"\$($(command -v brew) shellenv)\"" >> ~/.zprofile
fi

[ -x /usr/bin/jq ] || command -v jq >/dev/null || brew install jq
[ -d /Applications/SwiftBar.app ] || brew install --cask swiftbar

chmod +x "$PLUGIN_DIR"/*.sh
xattr -dr com.apple.quarantine "$DIR" 2>/dev/null || true

osascript -e 'quit app "SwiftBar"' 2>/dev/null || true
defaults write com.ameba.SwiftBar PluginDirectory "$PLUGIN_DIR"
sleep 1
open -a SwiftBar

echo "설치 완료. 메뉴바에 ✳︎ NN% 가 표시됩니다."
echo "- 키체인 접근 창이 뜨면 '항상 허용'"
echo "- 폴더 접근 권한 창이 뜨면 '허용'"
echo "- 재부팅 후 자동 실행: SwiftBar 메뉴 → Preferences → Launch at login"
