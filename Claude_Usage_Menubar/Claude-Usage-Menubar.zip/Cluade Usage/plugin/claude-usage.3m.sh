#!/bin/bash
# <swiftbar.hideRunInTerminal>true</swiftbar.hideRunInTerminal>
# <swiftbar.hideLastUpdated>false</swiftbar.hideLastUpdated>
# 내 계정의 월 지출 한도 사용량 (Enterprise, 터미널+앱 합산) — 비공식 /api/oauth/usage 사용
# 조회에는 터미널 Claude Code 로그인 정보를 쓰지만, 값 자체는 계정 전체 사용량(Claude 앱 포함)

JQ=$(PATH="/usr/bin:/opt/homebrew/bin:/usr/local/bin" command -v jq)
TOKEN=$(security find-generic-password -s "Claude Code-credentials" -w 2>/dev/null | $JQ -r '.claudeAiOauth.accessToken // empty')
if [ -z "$TOKEN" ]; then
  echo "✳︎ ?"; echo "---"; echo "키체인에서 토큰을 찾지 못함 — claude 로그인 필요"; exit 0
fi

RESP=$(curl -s -m 10 https://api.anthropic.com/api/oauth/usage \
  -H "Authorization: Bearer $TOKEN" -H "anthropic-beta: oauth-2025-04-20")

USED=$(echo "$RESP" | $JQ -r '.spend.used.amount_minor // empty' 2>/dev/null)
LIMIT=$(echo "$RESP" | $JQ -r '.spend.limit.amount_minor // empty' 2>/dev/null)
if [ -z "$USED" ] || [ -z "$LIMIT" ]; then
  echo "✳︎ !"; echo "---"; echo "사용량 조회 실패 (토큰 만료 시 claude 한 번 실행)"; echo "새로고침 | refresh=true"; exit 0
fi

PCT=$(( USED * 100 / LIMIT ))
if   [ $PCT -ge 90 ]; then COLOR="#FF453A"
elif [ $PCT -ge 75 ]; then COLOR="#FF9F0A"
else COLOR=""; fi

printf "✳︎ %d%%%s\n" "$PCT" "${COLOR:+ | color=$COLOR}"
echo "---"
printf "월 사용액: \$%d.%02d / \$%d.%02d\n" $((USED/100)) $((USED%100)) $((LIMIT/100)) $((LIMIT%100))
REM=$((LIMIT-USED)); [ $REM -lt 0 ] && REM=0
printf "남은 금액: \$%d.%02d\n" $((REM/100)) $((REM%100))
echo "---"
echo "새로고침 | refresh=true"
