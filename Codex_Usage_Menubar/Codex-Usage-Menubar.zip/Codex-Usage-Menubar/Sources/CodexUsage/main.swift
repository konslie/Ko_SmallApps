import AppKit
import SwiftUI

final class UsageModel: ObservableObject {
    @Published private(set) var snapshot: UsageSnapshot?
    @Published private(set) var isRefreshing = false
    @Published private(set) var isCodexAppRunning = false
    @Published private(set) var errorMessage: String?
    var onChange: (() -> Void)?

    init() {
        if let data = UserDefaults.standard.data(forKey: "lastUsageSnapshot") {
            snapshot = try? JSONDecoder().decode(UsageSnapshot.self, from: data)
        }
    }

    func setCodexAppRunning(_ running: Bool) {
        guard isCodexAppRunning != running else { return }
        isCodexAppRunning = running
        onChange?()
    }

    func refresh() {
        guard !isRefreshing else { return }
        isRefreshing = true
        errorMessage = nil
        let client = UsageClient()
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let result = Result { try client.fetch() }
            DispatchQueue.main.async {
                guard let self else { return }
                self.isRefreshing = false
                switch result {
                case .success(let snapshot):
                    self.snapshot = snapshot
                    self.errorMessage = nil
                    if let data = try? JSONEncoder().encode(snapshot) {
                        UserDefaults.standard.set(data, forKey: "lastUsageSnapshot")
                    }
                case .failure(let error): self.errorMessage = error.localizedDescription
                }
                self.onChange?()
            }
        }
    }
}

struct UsagePopover: View {
    @ObservedObject var model: UsageModel

    private var subtle: Color { .secondary }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text("Codex Usage").font(.system(size: 14, weight: .semibold))
                Spacer()
                if let plan = model.snapshot?.plan {
                    Text(plan.capitalized).font(.system(size: 12)).foregroundStyle(subtle)
                }
            }
            .padding(.bottom, 18)

            metric("5시간", window: model.snapshot?.fiveHour)
            metric("1주", window: model.snapshot?.week)
                .padding(.top, 19)

            Divider().padding(.top, 19)
            HStack {
                Text("재설정 이용권")
                Spacer()
                Text(model.snapshot?.resetCredits.map { "\($0)회 가능" } ?? "확인 불가")
            }
            .font(.system(size: 12))
            .padding(.vertical, 14)
            Divider()

            HStack(spacing: 8) {
                statusText
                    .font(.system(size: 11))
                    .foregroundStyle(model.errorMessage == nil ? subtle : Color.orange)
                    .lineLimit(2)
                Spacer(minLength: 4)
                Button(action: model.refresh) {
                    Label("새로고침", systemImage: "arrow.clockwise")
                        .font(.system(size: 12))
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                .disabled(model.isRefreshing)
            }
            .padding(.top, 13)
            HStack {
                Spacer()
                Button("앱 종료") { NSApp.terminate(nil) }
                    .buttonStyle(.plain)
                    .font(.system(size: 11))
                    .foregroundStyle(subtle)
            }
            .padding(.top, 11)
        }
        .padding(18)
        .frame(width: 296)
        .fixedSize(horizontal: false, vertical: true)
        .background(Color(nsColor: .windowBackgroundColor))
    }

    private func metric(_ title: String, window: LimitWindow?) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline) {
                Text(title).font(.system(size: 13))
                Spacer()
                HStack(alignment: .firstTextBaseline, spacing: 4) {
                    Text(window.map { "\($0.remaining)%" } ?? "—%")
                        .font(.system(size: 23, weight: .medium, design: .rounded))
                        .monospacedDigit()
                    Text("남음").font(.system(size: 11)).foregroundStyle(subtle)
                }
            }
            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.primary.opacity(0.10))
                    Capsule()
                        .fill((window?.remaining ?? 100) <= 20 ? Color.orange : Color.primary.opacity(0.53))
                        .frame(width: geometry.size.width * CGFloat(window?.remaining ?? 0) / 100)
                }
            }
            .frame(height: 4)
            Text(resetText(window?.resetsAt))
                .font(.system(size: 11))
                .foregroundStyle(subtle)
        }
        .accessibilityElement(children: .combine)
    }

    private var statusText: Text {
        if model.isRefreshing { return Text("갱신 중…") }
        if !model.isCodexAppRunning {
            if let date = model.snapshot?.fetchedAt {
                let time = date.formatted(date: .omitted, time: .shortened)
                return Text(model.errorMessage == nil ? "Codex 종료 · \(time) 마지막 값" : "Codex 종료 · \(time) 기준, 갱신 실패")
            }
            return Text("Codex 앱을 실행하면 사용량을 확인합니다")
        }
        if let error = model.errorMessage {
            if let date = model.snapshot?.fetchedAt {
                return Text("갱신 실패 · \(date.formatted(date: .omitted, time: .shortened)) 기준")
            }
            return Text(error)
        }
        if let date = model.snapshot?.fetchedAt {
            return Text("\(date.formatted(date: .omitted, time: .shortened)) 갱신 · 실행 중 2분 간격")
        }
        return Text("사용량 확인 전")
    }

    private func resetText(_ date: Date?) -> String {
        guard let date else { return "재설정 시각 확인 불가" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "ko_KR")
        formatter.dateStyle = Calendar.current.isDateInToday(date) ? .none : .medium
        formatter.timeStyle = .short
        return "\(formatter.string(from: date))에 재설정"
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    private let model = UsageModel()
    private var statusItem: NSStatusItem!
    private var popover: NSPopover!
    private var timer: Timer?
    private var outsideClickMonitor: Any?
    private var wakeObserver: NSObjectProtocol?
    private var launchObserver: NSObjectProtocol?
    private var terminateObserver: NSObjectProtocol?

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        statusItem = NSStatusBar.system.statusItem(withLength: 76)
        statusItem.button?.target = self
        statusItem.button?.action = #selector(togglePopover)
        statusItem.button?.imageScaling = .scaleNone

        popover = NSPopover()
        popover.behavior = .transient
        popover.contentViewController = NSHostingController(rootView: UsagePopover(model: model))
        outsideClickMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown, .otherMouseDown]) { [weak self] _ in
            guard let self,
                  self.popover.isShown,
                  let window = self.popover.contentViewController?.view.window,
                  !window.frame.contains(NSEvent.mouseLocation) else { return }
            DispatchQueue.main.async { [weak self] in
                guard let self, self.popover.isShown else { return }
                self.popover.performClose(nil)
            }
        }
        model.onChange = { [weak self] in self?.updateStatusItem() }
        updateStatusItem()
        let workspaceCenter = NSWorkspace.shared.notificationCenter
        launchObserver = workspaceCenter.addObserver(
            forName: NSWorkspace.didLaunchApplicationNotification, object: nil, queue: .main
        ) { [weak self] notification in self?.handleCodexProcessEvent(notification) }
        terminateObserver = workspaceCenter.addObserver(
            forName: NSWorkspace.didTerminateApplicationNotification, object: nil, queue: .main
        ) { [weak self] notification in self?.handleCodexProcessEvent(notification) }
        wakeObserver = NSWorkspace.shared.notificationCenter.addObserver(
            forName: NSWorkspace.didWakeNotification, object: nil, queue: .main
        ) { [weak self] _ in self?.synchronizeCodexState(refreshIfAlreadyRunning: true) }
        synchronizeCodexState()
    }

    func applicationWillTerminate(_ notification: Notification) {
        timer?.invalidate()
        if let outsideClickMonitor {
            NSEvent.removeMonitor(outsideClickMonitor)
            self.outsideClickMonitor = nil
        }
        let center = NSWorkspace.shared.notificationCenter
        [wakeObserver, launchObserver, terminateObserver].compactMap { $0 }.forEach(center.removeObserver)
    }

    @objc private func togglePopover() {
        guard let button = statusItem.button else { return }
        if popover.isShown { popover.performClose(nil) }
        else {
            popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
            if let window = popover.contentViewController?.view.window {
                window.setFrameOrigin(NSPoint(x: window.frame.origin.x, y: window.frame.origin.y - 18))
            }
        }
    }

    private func updateStatusItem() {
        guard let button = statusItem.button else { return }
        let five = model.snapshot?.fiveHour.map { "\($0.remaining)%" } ?? "—%"
        let week = model.snapshot?.week.map { "\($0.remaining)%" } ?? "—%"
        button.image = makeStatusImage(five: five, week: week)
        let state = model.isCodexAppRunning ? "Codex 실행 중" : "Codex 종료 · 마지막 값 유지"
        button.toolTip = "\(state) · 5시간 \(five), 1주 \(week)" + (model.errorMessage == nil ? "" : " · 갱신 실패")
    }

    private func handleCodexProcessEvent(_ notification: Notification) {
        guard let application = notification.userInfo?[NSWorkspace.applicationUserInfoKey] as? NSRunningApplication,
              application.bundleIdentifier == "com.openai.codex" else { return }
        synchronizeCodexState()
    }

    private func synchronizeCodexState(refreshIfAlreadyRunning: Bool = false) {
        let isRunning = NSWorkspace.shared.runningApplications.contains {
            $0.bundleIdentifier == "com.openai.codex"
        }
        let changed = model.isCodexAppRunning != isRunning
        model.setCodexAppRunning(isRunning)

        if isRunning {
            if timer == nil {
                timer = Timer.scheduledTimer(withTimeInterval: 120, repeats: true) { [weak self] _ in
                    self?.model.refresh()
                }
            }
            if changed || refreshIfAlreadyRunning { model.refresh() }
        } else {
            timer?.invalidate()
            timer = nil
        }
        updateStatusItem()
    }

    private func makeStatusImage(five: String, week: String) -> NSImage {
        let size = NSSize(width: 72, height: 22)
        let image = NSImage(size: size, flipped: false) { rect in
            NSColor.black.setFill()
            let logoURL = Bundle.main.url(forResource: "codex-template", withExtension: "png")
            if let logoURL, let logo = NSImage(contentsOf: logoURL) {
                logo.draw(in: NSRect(x: 1, y: 2, width: 18, height: 18))
            } else {
                let fallback = NSImage(systemSymbolName: "curlybraces", accessibilityDescription: nil)
                fallback?.draw(in: NSRect(x: 1, y: 2, width: 18, height: 18))
            }
            let font = NSFont.systemFont(ofSize: 9, weight: .medium)
            let attributes: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: NSColor.black]
            ("5h" as NSString).draw(at: NSPoint(x: 24, y: 11), withAttributes: attributes)
            ("1w" as NSString).draw(at: NSPoint(x: 24, y: 1), withAttributes: attributes)
            let valueX = 24 + ("5h" as NSString).size(withAttributes: attributes).width + 5
            (five as NSString).draw(at: NSPoint(x: valueX, y: 11), withAttributes: attributes)
            (week as NSString).draw(at: NSPoint(x: valueX, y: 1), withAttributes: attributes)
            return true
        }
        image.isTemplate = true
        return image
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.run()
