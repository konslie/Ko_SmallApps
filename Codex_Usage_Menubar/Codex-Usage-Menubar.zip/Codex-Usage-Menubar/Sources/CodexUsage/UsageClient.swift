import Foundation

struct LimitWindow: Codable {
    let remaining: Int
    let resetsAt: Date?
}

struct UsageSnapshot: Codable {
    let fiveHour: LimitWindow?
    let week: LimitWindow?
    let resetCredits: Int?
    let plan: String?
    let fetchedAt: Date
}

enum UsageError: LocalizedError {
    case executableMissing
    case timedOut
    case processEnded
    case invalidResponse
    case server(String)

    var errorDescription: String? {
        switch self {
        case .executableMissing: return "Codex 실행 파일을 찾을 수 없습니다."
        case .timedOut: return "조회 시간이 초과되었습니다."
        case .processEnded: return "Codex 사용량 조회가 종료되었습니다."
        case .invalidResponse: return "사용량 응답을 읽을 수 없습니다."
        case .server(let message): return message
        }
    }
}

final class UsageClient {
    private let fileManager = FileManager.default

    func fetch() throws -> UsageSnapshot {
        guard let executable = findExecutable() else { throw UsageError.executableMissing }
        let process = Process()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = ["app-server"]
        let input = Pipe()
        let output = Pipe()
        process.standardInput = input
        process.standardOutput = output
        process.standardError = FileHandle.nullDevice

        try process.run()
        let deadline = Date().addingTimeInterval(15)
        let watchdog = DispatchWorkItem { [weak process] in
            if process?.isRunning == true { process?.terminate() }
        }
        DispatchQueue.global().asyncAfter(deadline: .now() + 15, execute: watchdog)
        defer {
            watchdog.cancel()
            if process.isRunning { process.terminate() }
            try? input.fileHandleForWriting.close()
            try? output.fileHandleForReading.close()
        }

        try send([
            "method": "initialize", "id": 1,
            "params": ["clientInfo": [
                "name": "codex_usage", "title": "Codex Usage", "version": "0.1.0"
            ]]
        ], to: input.fileHandleForWriting)
        var buffer = Data()
        _ = try receive(id: 1, from: output.fileHandleForReading, buffer: &buffer, deadline: deadline)
        try send(["method": "initialized", "params": [:]], to: input.fileHandleForWriting)
        try send(["method": "account/rateLimits/read", "id": 2], to: input.fileHandleForWriting)
        let response = try receive(id: 2, from: output.fileHandleForReading, buffer: &buffer, deadline: deadline)
        guard let result = response["result"] as? [String: Any] else { throw UsageError.invalidResponse }
        return try parse(result)
    }

    private func findExecutable() -> String? {
        let candidates = [
            "/Applications/ChatGPT.app/Contents/Resources/codex",
            "/opt/homebrew/bin/codex",
            "/usr/local/bin/codex"
        ]
        return candidates.first(where: { fileManager.isExecutableFile(atPath: $0) })
    }

    private func send(_ object: [String: Any], to handle: FileHandle) throws {
        let data = try JSONSerialization.data(withJSONObject: object) + Data([0x0a])
        try handle.write(contentsOf: data)
    }

    private func receive(id: Int, from handle: FileHandle, buffer: inout Data, deadline: Date) throws -> [String: Any] {
        while Date() < deadline {
            if let newline = buffer.firstIndex(of: 0x0a) {
                let line = Data(buffer[..<newline])
                buffer.removeSubrange(...newline)
                guard let message = try? JSONSerialization.jsonObject(with: line) as? [String: Any] else { continue }
                guard message["id"] as? Int == id else { continue }
                if let error = message["error"] as? [String: Any] {
                    throw UsageError.server(error["message"] as? String ?? "사용량 조회에 실패했습니다.")
                }
                return message
            }
            // FileHandle may wait for the requested byte count on a pipe; one byte keeps JSONL responsive.
            let chunk = try handle.read(upToCount: 1) ?? Data()
            if chunk.isEmpty { throw Date() >= deadline ? UsageError.timedOut : UsageError.processEnded }
            buffer.append(chunk)
        }
        throw UsageError.timedOut
    }

    private func parse(_ result: [String: Any]) throws -> UsageSnapshot {
        let buckets = result["rateLimitsByLimitId"] as? [String: Any]
        let codex = (buckets?["codex"] as? [String: Any]) ?? (result["rateLimits"] as? [String: Any])
        guard let codex else { throw UsageError.invalidResponse }
        let windows = [codex["primary"], codex["secondary"]].compactMap { $0 as? [String: Any] }
        func window(minutes: Int) -> LimitWindow? {
            guard let value = windows.first(where: { ($0["windowDurationMins"] as? Int) == minutes }),
                  let used = value["usedPercent"] as? Double else { return nil }
            let remaining = Int((100 - used).rounded()).clamped(to: 0...100)
            let resetsAt = (value["resetsAt"] as? Double).map(Date.init(timeIntervalSince1970:))
            return LimitWindow(remaining: remaining, resetsAt: resetsAt)
        }
        let resetInfo = result["rateLimitResetCredits"] as? [String: Any]
        return UsageSnapshot(
            fiveHour: window(minutes: 300),
            week: window(minutes: 10080),
            resetCredits: resetInfo?["availableCount"] as? Int,
            plan: codex["planType"] as? String,
            fetchedAt: Date()
        )
    }
}

private extension Comparable {
    func clamped(to range: ClosedRange<Self>) -> Self { min(max(self, range.lowerBound), range.upperBound) }
}
