#!/bin/bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")" && pwd)"
app_dir="$project_dir/dist/Codex Usage.app"
module_cache="${TMPDIR:-/tmp}/codex-usage-module-cache"
sdk="$(xcrun --sdk macosx --show-sdk-path)"
if [[ -d /Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk ]]; then
    sdk="/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk"
fi
mkdir -p "$project_dir/.build" "$module_cache"
swiftc -O -target arm64-apple-macosx13.0 -sdk "$sdk" -module-cache-path "$module_cache" \
    -o "$project_dir/.build/CodexUsage" \
    "$project_dir/Sources/CodexUsage/main.swift" \
    "$project_dir/Sources/CodexUsage/UsageClient.swift"
mkdir -p "$app_dir/Contents/MacOS" "$app_dir/Contents/Resources"
cp "$project_dir/.build/CodexUsage" "$app_dir/Contents/MacOS/CodexUsage"
cp "$project_dir/Info.plist" "$app_dir/Contents/Info.plist"
cp "$project_dir/Resources/chatgptTemplate@2x.png" "$app_dir/Contents/Resources/codex-template.png"
codesign --force --sign - "$app_dir" >/dev/null
echo "$app_dir"
